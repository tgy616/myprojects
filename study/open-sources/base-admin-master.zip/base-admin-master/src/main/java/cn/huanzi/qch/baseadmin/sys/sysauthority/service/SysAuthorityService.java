package cn.huanzi.qch.baseadmin.sys.sysauthority.service;

import cn.huanzi.qch.baseadmin.common.service.*;
import cn.huanzi.qch.baseadmin.sys.sysauthority.pojo.SysAuthority;
import cn.huanzi.qch.baseadmin.sys.sysauthority.vo.SysAuthorityVo;

public interface SysAuthorityService extends CommonService<SysAuthorityVo, SysAuthority, String> {
}
