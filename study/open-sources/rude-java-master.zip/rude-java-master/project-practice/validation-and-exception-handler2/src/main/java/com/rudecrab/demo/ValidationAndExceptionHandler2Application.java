package com.rudecrab.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationAndExceptionHandler2Application {

    public static void main(String[] args) {
        SpringApplication.run(ValidationAndExceptionHandler2Application.class, args);
    }

}
