# 【项目实践】学习SpringBoot之前先学学SSM整合

## 项目运行

本项目使用Maven构建，将项目clone下来后导入到IDE中即可启动

## 项目讲解

https://juejin.im/post/6844904099545088014

