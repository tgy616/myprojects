package com.rudecrab.loginsession.entity;

import lombok.Data;

/**
 * @author RudeCrab
 */
@Data
public class User {
    private String username;
    private String password;
}
