package com.rudecrab.loginsession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginSessionApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoginSessionApplication.class, args);
    }

}
