package com.rudecrab.loginsession.service;

/**
 * @author RudeCrab
 */
public interface UserService {
    void doSomething();
}
