package com.rudecrab.loginjwt.service;

/**
 * @author RudeCrab
 */
public interface UserService {
    void doSomething();
}
