# 【项目实践】在用安全框架前，我想先让你手撸一个登陆认证

## 项目运行

login-demo是Maven聚合项目，分为两个模块：

login-session：使用`Session`完成登录认证功能

login-jwt：使用`JWT`完成登录认证功能



将项目导入IDE，即可启动两个模块！

## 文章讲解

https://blog.csdn.net/RudeCrab/article/details/108317569