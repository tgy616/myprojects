<template>
    <h1>这是首页</h1>
</template>

<script>
    export default {
        name: "Index"
    }
</script>

<style scoped>

</style>