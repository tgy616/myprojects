<template>
    <h1>这是设置页面</h1>
</template>

<script>
    export default {
        name: "Setting"
    }
</script>

<style scoped>

</style>