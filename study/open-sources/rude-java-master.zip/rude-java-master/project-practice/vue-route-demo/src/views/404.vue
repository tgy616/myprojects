<template>
    <h1>这是404页面！</h1>
</template>

<script>
    export default {
        name: "404"
    }
</script>

<style scoped>

</style>